import express from 'express';
import cors from 'cors';
import multer from 'multer';
import dotenv from 'dotenv';
import { GoogleGenerativeAI } from '@google/generative-ai';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);

app.post('/api/analyze', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No image file provided' });
    }

    // Convert image to base64
    const imageBase64 = req.file.buffer.toString('base64');

    // Initialize the model
    const model = genAI.getGenerativeModel({ model: "gemini-pro-vision" });

    // Prepare the prompt
    const prompt = `Analyze this dental image for cavities. Focus on the following aspects:
    1. Presence of cavities
    2. Affected surface (Occlusal, Mesial, Distal, Facial, or Lingual)
    3. Severity level
    4. Recommendations for treatment
    
    Provide a structured analysis.`;

    // Generate content
    const result = await model.generateContent([
      prompt,
      {
        inlineData: {
          mimeType: "image/jpeg",
          data: imageBase64
        }
      }
    ]);

    const response = await result.response;
    const text = response.text();

    // Parse the AI response and structure it
    // This is a simplified example - you would want to add more sophisticated parsing
    const analysis = {
      hasCavity: text.toLowerCase().includes('cavity'),
      surface: text.match(/(?:occlusal|mesial|distal|facial|lingual)/i)?.[0] || 'Unknown',
      severity: text.match(/(?:mild|moderate|severe)/i)?.[0] || 'Unknown',
      recommendations: text.split('Recommendations:')[1]?.trim() || 'Please consult a dentist for proper evaluation',
      fullAnalysis: text
    };

    res.json(analysis);
  } catch (error) {
    console.error('Analysis error:', error);
    res.status(500).json({ error: 'Failed to analyze image' });
  }
});

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../dist')));
  
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../dist/index.html'));
  });
}

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});