import React from 'react';

const Analysis = ({ analysis, loading }) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center p-4">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!analysis) return null;

  return (
    <div className="bg-white rounded-lg shadow p-6 mt-6">
      <h2 className="text-xl font-semibold mb-4">Analysis Results</h2>
      <div className="prose max-w-none">
        <div className="space-y-4">
          <div>
            <h3 className="font-medium text-gray-900">Cavity Detection:</h3>
            <p className="text-gray-700">{analysis.hasCavity ? "Cavity detected" : "No cavity detected"}</p>
          </div>
          {analysis.hasCavity && (
            <>
              <div>
                <h3 className="font-medium text-gray-900">Affected Surface:</h3>
                <p className="text-gray-700">{analysis.surface}</p>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Severity Level:</h3>
                <p className="text-gray-700">{analysis.severity}</p>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Recommendations:</h3>
                <p className="text-gray-700">{analysis.recommendations}</p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Analysis;