import React, { useState } from 'react';
import Header from './components/Header';
import ImageUpload from './components/ImageUpload';
import Analysis from './components/Analysis';
import { analyzeImage } from './services/api';
import './App.css';

function App() {
  const [selectedImage, setSelectedImage] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleImageUpload = async (file) => {
    setSelectedImage(URL.createObjectURL(file));
    setLoading(true);
    setError(null);

    try {
      const result = await analyzeImage(file);
      setAnalysis(result);
    } catch (err) {
      setError('Failed to analyze image. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="bg-white rounded-lg shadow p-6">
            <ImageUpload onImageUpload={handleImageUpload} />
            
            {selectedImage && (
              <div className="mt-6">
                <img
                  src={selectedImage}
                  alt="Selected dental image"
                  className="max-w-full h-auto rounded-lg"
                />
              </div>
            )}

            {error && (
              <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-md">
                {error}
              </div>
            )}

            <Analysis analysis={analysis} loading={loading} />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;