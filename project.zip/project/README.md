# Dental Cavity Detection AI

An AI-powered application for early detection of dental cavities using image analysis and the Google Gemini Pro Vision API.

## Features

- Upload dental images for analysis
- AI-powered cavity detection
- Surface identification (Occlusal, Mesial, Distal, Facial, Lingual)
- Severity assessment
- Treatment recommendations
- Real-time analysis results

## Tech Stack

- Frontend: React + Vite
- Backend: Node.js + Express
- AI: Google Gemini Pro Vision API
- Styling: TailwindCSS
- Image Handling: Multer
- API Communication: Fetch API

## Setup

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file with your Google API key:
   ```
   GOOGLE_API_KEY=your_key_here
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```
5. Start the backend server:
   ```bash
   npm run server
   ```

## Usage

1. Open the application in your browser
2. Upload a dental image using the drag-and-drop interface
3. Wait for the AI analysis
4. Review the detailed results including cavity detection, affected surface, and recommendations

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.